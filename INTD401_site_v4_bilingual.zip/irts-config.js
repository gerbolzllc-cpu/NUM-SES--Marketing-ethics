/* INTD401 — Ирцийн бүртгэлийн нэгдсэн тохиргоо.
   Apps Script-ээ deploy хийсний дараа гарсан ".../exec" URL-ийг ЗӨВХӨН ЭНД тавина —
   irts.html болон лекцийн хуудсуудын (index, lekts1, lekts2) санал авах слайд бүгд эндээс уншина.
   Жишээ: 'https://script.google.com/macros/s/AKfycb.../exec' */
window.INTD401_IRTS = {
  SCRIPT_URL: '',
  WINDOW: { start: '20:05', end: '20:15' },   // бүртгэл нээлттэй цонх (Улаанбаатарын цаг); сервер мөн шалгана
  TZ: 'Asia/Ulaanbaatar'
};
